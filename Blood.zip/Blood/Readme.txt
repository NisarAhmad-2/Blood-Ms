How to run Blood Donor Management Project using CodeIgniter

Download the zip file
Extract the file and copy blood  folder
Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)
Open PHPMyAdmin (http://localhost/phpmyadmin)
Create a database with name blood
Import blood.sql file(given inside the zip package in SQL file folder)
Run the script http://localhost/blood (frontend)

Blood Donor Credential
Username: johndoe@gmail.com
Password: Test@123

Admin Credential
Username: admin@gmail.com
Password: Test@123

Users can search the Blood donor using blood Group or State.